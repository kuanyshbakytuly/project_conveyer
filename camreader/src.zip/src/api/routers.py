from fastapi import APIRouter

camera_router = APIRouter()
